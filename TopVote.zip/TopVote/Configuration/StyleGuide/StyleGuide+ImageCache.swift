//
//  StyleGuide+ImageCache.swift
//  //  iOS Foundation
//
//  Created by Luke McDonald on 8/26/17.
//  Copyright © 2017 Luke McDonald. All rights reserved.
//

import Foundation
import UIKit

extension StyleGuide {
    struct ImageCache {
     
    }
}
