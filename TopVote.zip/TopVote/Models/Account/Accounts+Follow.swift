//
//  Accounts+Following.swift
//  Topvote
//
//  Created by Benjamin Stahlhood on 5/5/18.
//  Copyright © 2018 Top, Inc. All rights reserved.
//

import Foundation

struct FollowInterceptor: ModelGenerator {
    var following: Accounts?
    var followers: Accounts?
}
