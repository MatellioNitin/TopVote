//
//  Model+JSON.swift
//  Topvote
//
//  Created by Benjamin Stahlhood on 5/5/18.
//  Copyright © 2018 Top, Inc. All rights reserved.
//

import Foundation

protocol ModelJSON: ModelJSONGenerator { }
