//
//  Device+Provider.swift
//  Topvote
//
//  Created by Benjamin Stahlhood on 5/5/18.
//  Copyright © 2018 Top, Inc. All rights reserved.
//

import Foundation

extension TVDevice {
    struct Location: ModelGenerator {
        var index: String?
        
        var type: Double?
    }
}
