//
//  TVfpPickerController.swift
//  TopVote
//
//  Created by Kurt Jensen on 3/10/16.
//  Copyright © 2016 TopVote. All rights reserved.
//

import UIKit
//import FPPicker

//class TVfpPickerController: FPPickerController {
//
//    override func viewDidLoad() {
//        super.viewDidLoad()
//
//        let theme = FPTheme()
//
//        // Navigation bar
//        theme.navigationBarStyle = .black;
//        theme.navigationBarBackgroundColor = Style.tintColor
//        theme.navigationBarTintColor = UIColor.white
//
//        // Table view
//        theme.headerFooterViewTintColor = Style.tintColor
//        theme.headerFooterViewTextColor = UIColor.white
//        theme.tableViewCellTextColor = UIColor.black
//        theme.tableViewCellTintColor = Style.tintColor
//        theme.tableViewCellSelectedTextColor = UIColor.black
//
//        // Upload button
//        theme.uploadButtonBackgroundColor = UIColor.white
//        theme.uploadButtonHappyTextColor = Style.tintColor
//        theme.uploadButtonAngryTextColor = UIColor.red
//
//        self.theme = theme
//    }
//
//}

